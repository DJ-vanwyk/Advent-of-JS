# COLORS

- Background teal: #37B2C3
- White keys will change to yellow #ffd200
- Black keys will change to pink #f40082
